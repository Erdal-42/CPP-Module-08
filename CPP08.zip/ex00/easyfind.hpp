/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   easyfind.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ekocak@student.42.org.tr>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/24 18:22    by ekocak            #+#    #+#             */
/*   Updated: 2023/08/24 18:22    by ekocak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef EASYFIND_HPP
# define EASYFIND_HPP

#include <vector>
#include <iostream>
#include <algorithm>

class NotFoundException : public std::exception 
{
    public:
        virtual const char *what() const throw() 
        {
            return "Handled Exception: ";
        }
};

/*
 * we declare a template function with a template parameter T.
 * T is the type of the data to be stored in the vector.
 * The first parameter of the function is a constant reference
 * to a vector of type T. We will be searching for the second
 * parameter within the container.
 * The second parameter is a value of type integer.
 */ 
template <typename T>
typename T::const_iterator easyfind(const T& container, int num)
{

    typename T::const_iterator it = std::find(container.begin(), container.end(), num);
    if (it == container.end())
        throw (NotFoundException());
    return (it);
}

#endif
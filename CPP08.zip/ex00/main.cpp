/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ekocak@student.42.org.tr>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/24 18:22    by ekocak            #+#    #+#             */
/*   Updated: 2023/08/24 18:22    by ekocak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "easyfind.hpp"

template <typename T>
std::ostream &operator<<(std::ostream &os, const std::vector<T>& container) 
{
    os << "{";
    typename std::vector<T>::const_iterator it = container.begin();
    if (it != container.end()) {
        os << *it;
        ++it;
    }
    for (; it != container.end(); ++it) {
        os << ", " << *it;
    }
    os << "}";
    return os;
}

template <typename T>
void test(const std::vector<T>& numbers, int value_to_find)
{
    typename std::vector<T>::const_iterator iter;
    int index;

    try
    {
        iter = easyfind(numbers, value_to_find);
    } catch (NotFoundException(&e))
    {
        std::cout << e.what() << "Value " << value_to_find << " not found in container " << numbers << std::endl;
    }
    index = iter - numbers.begin();
    if (index >= 0 && index < (int)numbers.size())
        std::cout << "Value " << value_to_find << " found at index " << index << " in container " << numbers << std::endl; 
}

int main()
{
    std::vector<int> numbers = {5, 2, 8, 1, 3};
    int value_to_find = 8;
    test(numbers, value_to_find);

    std::vector<int> more_numbers = {8, 2, 8, 1, 3};
    test(more_numbers, value_to_find);

    std::vector<int> even_more_numbers = {5, 2, 3, 1, 8};
    test(even_more_numbers, value_to_find);

    std::vector<int> yet_more_numbers = {5, 2, 3, 1, 0};
    test(yet_more_numbers, value_to_find);

    return 0;
}

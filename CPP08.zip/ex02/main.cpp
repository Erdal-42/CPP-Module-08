/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ekocak@student.42.org.tr>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/29 00:33    by ekocak            #+#    #+#             */
/*   Updated: 2023/08/29 00:33    by ekocak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "MutantStack.hpp"
#include <deque>
#include <iostream>
#include <list>


void	testSubject(void);
void	testStringListMutantStack(void);


int	main(void)
{
	::testSubject();
	::testStringListMutantStack();
	return 0;
}

void	testSubject(void)
{
	std::cout << "=======SUBJECT TESTS=======" << std::endl;

	{
		std::cout << std::endl << "MUTANT STACK" << std::endl;
		MutantStack<int> mstack;
		mstack.push(5);
		mstack.push(17);
		std::cout << "Stack top (expecting 17): " << mstack.top() << std::endl;
		mstack.pop();
		std::cout << "Stack size (expecting 1): " << mstack.size() << std::endl;
		mstack.push(3);
		mstack.push(5);
		mstack.push(737);
		mstack.push(0);
		std::cout << "Iterating over mstack from begin() to end() (expecting 5, 3, 5, 737, 0): " << std::endl;
		MutantStack<int>::iterator it = mstack.begin();
		MutantStack<int>::iterator ite = mstack.end();
		++it;
		--it;
		while (it != ite)
		{
			std::cout << *it << " ";
			++it;
		}
		std::stack<int> s(mstack);
		std::cout << std::endl;
	}
	{
		std::cout << std::endl << "LIST" << std::endl;
		std::list<int> mstack;
		mstack.push_back(5);
		mstack.push_back(17);
		std::cout << "List \"top\" (back) (expecting 17): " << mstack.back() << std::endl;
		mstack.pop_back();
		std::cout << "Stack size (expecting 1): " << mstack.size() << std::endl;
		mstack.push_back(3);
		mstack.push_back(5);
		mstack.push_back(737);
		mstack.push_back(0);
		std::cout << "Iterating over mstack list from begin() to end() (expecting 5, 3, 5, 737, 0): " << std::endl;
		std::list<int>::iterator it = mstack.begin();
		std::list<int>::iterator ite = mstack.end();
		++it;
		--it;
		while (it != ite)
		{
			std::cout << *it << " ";
			++it;
		}
		std::cout << std::endl;
	}
	std::cout << std::endl;
}

void	testStringListMutantStack(void)
{
		std::cout << "STRING LIST" << std::endl;
		MutantStack<std::string, std::list<std::string>> mstack;
		mstack.push("Istanbul");
		mstack.push("Ankara");
		std::cout << "Stack top (expecting \"Ankara\"): " << mstack.top() << std::endl;
		mstack.pop();
		std::cout << "Stack size (expecting 1): " << mstack.size() << std::endl;
		mstack.push("Izmir");
		mstack.push("Kocaeli");
		mstack.push("Denizli");
		mstack.push("Trabzon");
		std::cout << "Iterating over mstack from begin() to end() (expecting Istanbul, Izmir, Kocaeli, Denizli, Trabzon): " << std::endl;
		MutantStack<std::string, std::list<std::string>>::iterator it = mstack.begin();
		MutantStack<std::string, std::list<std::string>>::iterator ite = mstack.end();
		++it;
		--it;
		while (it != ite)
		{
			std::cout << *it << " ";
			++it;
		}
		std::stack<std::string, std::list<std::string>> s(mstack);
		std::cout << std::endl;	
}
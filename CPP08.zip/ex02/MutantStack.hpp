/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   MutantStack.hpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ekocak@student.42.org.tr>                  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/08/29 00:33    by ekocak            #+#    #+#             */
/*   Updated: 2023/08/29 00:33    by ekocak           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MUTANTSTACK_H
# define MUTANTSTACK_H

#include <stack>
#include <ostream>
#include <algorithm>

/* 
 * template <typename T, typename C = std::deque<T>>: This line starts 
 * the declaration of the template class MutantStack. It takes two 
 * template parameters: T (the type of elements in the stack) and C (the 
 * underlying container type for the stack, defaulted to std::deque<T>).
 */  
template < typename T, typename C = std::deque<T> >
class MutantStack : public std::stack<T, C>
{
	public:
		typedef typename std::stack<T, C>::container_type::iterator					iterator;
		typedef typename std::stack<T, C>::container_type::const_iterator			const_iterator;
		typedef typename std::stack<T, C>::container_type::reverse_iterator			reverse_iterator;
		typedef typename std::stack<T, C>::container_type::const_reverse_iterator	const_reverse_iterator;
 
		MutantStack<T, C>(void) : std::stack<T, C>() {};
		MutantStack<T, C>(const MutantStack<T, C>& source) : std::stack<T, C>(source) {};
		~MutantStack<T, C>(void) {};
		MutantStack<T, C> &	operator=(const MutantStack<T, C>& source) 
		{
			if (this != &source)
				this->c = source.c;
			return (*this);
		}
		
		MutantStack<T, C>::iterator	begin(void) 
		{
			return (this->c.begin());
		}

		MutantStack<T, C>::iterator	end(void) 
		{
			return (this->c.end());
		}

		MutantStack<T, C>::const_iterator	begin(void) const 
		{
			return (this->c.begin());
		}

		MutantStack<T, C>::const_iterator	end(void) const 
		{
			return (this->c.end());
		}

		MutantStack<T, C>::reverse_iterator	rbegin(void) 
		{
			return (this->c.rbegin());
		}

		MutantStack<T, C>::reverse_iterator	rend(void) 
		{
			return (this->c.rend());
		}

		MutantStack<T, C>::const_reverse_iterator	rbegin(void) const 
		{
			return (this->c.rbegin());
		}

		MutantStack<T, C>::const_reverse_iterator	rend(void) const 
		{
					return (this->c.rend());
		}
};

#endif

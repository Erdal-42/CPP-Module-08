#include "Span.hpp"

void    testShortestSpan(Span *span)
{
    try
    {
        span->shortestSpan();
    } catch (Span::InsufficientNumberofElements(&e))
    {
        std::cout << "Shortest Span: " << e.what() << std::endl; 
    }    
}

void    testLongestSpan(Span *span)
{
    try
    {
        span->longestSpan();
    } catch (Span::InsufficientNumberofElements(&e))
    {
        std::cout << "Longest Span: " << e.what() << std::endl; 
    }    
}

int main()
{
    Span *span1 = new Span(10);
    std::cout << "=======SPAN WITH EMPTY CONTAINER=======" << std::endl;
    std::cout << *span1 << std::endl;
    testShortestSpan(span1);
    testLongestSpan(span1);
    std::cout << "=======SPAN WITH SINGLE ELEMENT CONTAINER=======" << std::endl;
    try
    {
        span1->addNumber(20);
    } catch (Span::ContainerFullException(&e))
    {
        std::cout << e.what() << std::endl;
    }
    Span span2(*span1);
    testShortestSpan(&span2);
    testLongestSpan(&span2);
    
    std::cout << "=======SPAN WITH 10 ELEMENT CONTAINER=======" << std::endl;
    for (int i = 1; i < 6; i ++)
    {
        try
        {
            span1->addNumber(i);
        } catch (Span::ContainerFullException(&e))
        {
            std::cout << e.what() << std::endl;
        }
    }
    std::cout << *span1 << std::endl;
    testShortestSpan(span1);
    testLongestSpan(span1);
    std::cout << "=======SPAN WITH 100.000 ELEMENT CONTAINER=======" << std::endl;
    Span    span3;
    span3 = span2;
    span3.addNumber(-1);
    span3.addNumber(0);
    span3.buildSpan(6);
    testShortestSpan(&span3);
    testLongestSpan(&span3);

    delete span1;
    //delete span3;

    return (0); 
}

/*
int main()
{
    Span sp = Span(5);
    sp.addNumber(6);
    sp.addNumber(3);
    sp.addNumber(17);
    sp.addNumber(9);
    sp.addNumber(11);
    std::cout << sp.shortestSpan() << std::endl;
    std::cout << sp.longestSpan() << std::endl;
    return 0;
}
*/


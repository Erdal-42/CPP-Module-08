#ifndef SPAN_HPP
# define SPAN_HPP

#include <iostream>
#include <exception>
#include <algorithm>
#include <vector>
#include <ostream>
#include <numeric>
#include <cstdlib>
#include <ctime>

#define DEBUG 1

/*
 * Develop a Span class that can store a maximum 
 * of N integers. N is an unsigned int variable 
 * and will be the only parameter passed to the 
 * constructor.
 */
 
class Span
{
    private:
        unsigned            _N;
        std::vector<int>    _container;
    public:
        Span();
        Span(unsigned);
        ~Span();
        Span(const Span&); 
        Span& operator=(const Span& other);
        void        setN(unsigned);
        unsigned    getN() const;
        const std::vector<int>& getContainer() const; 
        void        addNumber(int);
        void        buildSpan(unsigned);
        unsigned    shortestSpan();
        unsigned    longestSpan();
        class ContainerFullException : public std::exception
        {
            public:
                virtual const char  *what() const throw();
        };
        class InsufficientNumberofElements : public std::exception
        {
            public:
                virtual const char  *what() const throw();
        };
};

std::ostream &operator<<(std::ostream &, const Span&);

#endif
#include "Span.hpp"

Span::Span(): _N(0)
{
#if DEBUG
    std::cout << "Default Construction: " << *this << std::endl;  
#endif
}

Span::Span(unsigned theN)
{
    _N = theN;
    _container.reserve(theN);
#if DEBUG
    std::cout << "Parametized Construction: " << *this << std::endl;  
#endif    
}

Span::~Span()
{
#if DEBUG
    std::cout << "Destroying: " << *this << std::endl;  
#endif    
}

Span::Span(const Span& other)
{
    _N = other._N;
    _container = other._container;
#if DEBUG
    std::cout << "Copy Constructed: " << *this << std::endl;  
#endif
}

Span& Span::operator=(const Span& other)
{
    if (this != &other)
    {
        _N = other._N;
        _container = other._container;
    }
#if DEBUG
    std::cout << "Assigned: " << *this << std::endl;  
#endif
    return *this;
}

void    Span::setN(unsigned theN)
{
    _N = theN;
    _container.reserve(theN);
}

unsigned Span::getN() const
{
    return (_N);
}

const std::vector<int>& Span::getContainer() const 
{
    return _container;
}

void    Span::addNumber(int num)
{
    if (!_N)
    {
        std::cout << "Cannot add number to a Span with _N atribute value 0" << std::endl;
        return ;
    } 
    if (_container.size() == _N || !_N)
        throw ContainerFullException();
    else
        _container.push_back(num);
#if DEBUG
    std::cout << "Pushed the element " << num << " to " << *this << std::endl;  
#endif
}

void    Span::buildSpan(unsigned numIntegers)
{
    //I will build a new container with the required size.
    std::vector<int> newContainer;
    newContainer.reserve(numIntegers);
    //copy existing values into new container
    std::vector<int>::const_iterator iter = _container.begin();
    while (_container.size() && newContainer.size() < numIntegers)
    {
        newContainer.push_back(*iter);
        if (iter == _container.end())
            break ;
        ++ iter;
    }
    _N = numIntegers;
    // Seed the random number generator
    srand(static_cast<unsigned int>(time(NULL)));
    unsigned i = 0;
    while (newContainer.size() < _N) 
    {
        int randomInteger = rand(); // Generate a random integer
        newContainer.push_back(randomInteger);
        ++ i;
    }
    if (_container.size())
        std::vector<int>().swap(_container);
    _container = newContainer;
#if DEBUG
    std::cout << "Completed " << *this << " to " << numIntegers << " elements by entering " << i+1 << " elements." << std::endl;  
#endif
}

unsigned    Span::shortestSpan()
{
    if (_container.size() < 2)
        throw InsufficientNumberofElements();
    else
    {
        // Sort the vector to make sure adjacent elements are considered
        std::sort(_container.begin(), _container.end());

        // Calculate adjacent differences
        std::vector<int> differences(_container.size());    //a new vector is declared where the number of items is equal to the container size
                                                        //this new vector will contain the diffrences between sorted items. 
        std::adjacent_difference(_container.begin(), _container.end(), differences.begin());    //This algorithm function starts calculating the 
                                                        //diffrences and saves every diffrence in the new vector container.
                            //the adjacent_diffrence function takes 3 parameters (where the iterator of the source container begins and ends 
                            //and where the destination container iterator begins)
        // Find the shortest difference
        //here we find the max value in the destination container. The iterator starting position 
        //is advanced by one because that is supposed to be pointing at an initial value supposedly the diffrence between the same value (starting number)
        int smallestDifference = *std::min_element(differences.begin() + 1, differences.end());
#if DEBUG
    std::cout << *this << " \tLONGEST SPAN: " << smallestDifference << std::endl;  
#endif
        return (smallestDifference);
    }
}

unsigned    Span::longestSpan()
{
    if (_container.size() < 2)
        throw InsufficientNumberofElements();
    else
    {
        // Find the maximum element
        std::vector<int>::iterator maxElement = std::max_element(_container.begin(), _container.end());

        // Find the minimum element
        std::vector<int>::iterator minElement = std::min_element(_container.begin(), _container.end());
#if DEBUG
    std::cout << *this << " \tLONGEST SPAN: " << *maxElement - *minElement << std::endl;  
#endif
        return *maxElement - *minElement;    
    }
}

const char  *Span::ContainerFullException::what() const throw()
{
    return ("Cannot add additional elements as the container reserve is already full.");    
}

const char  *Span::InsufficientNumberofElements::what() const throw()
{
    return ("Insufficient number of elements in container for span calculations.");
}

std::ostream &operator<<(std::ostream &os, const Span& span) 
{
    os << "{";
    const std::vector<int>& containerRef = span.getContainer();
    std::vector<int>::const_iterator iter = containerRef.begin();
    if (iter != containerRef.end()) {
        os << *iter;
        ++ iter;
    }
    int i = 1;
    for (; iter != containerRef.end(); ++ iter) {
        os << ", " << *iter;
        ++ i;
        if (i == 9)
            break ;
    }
    if (i == 9)
        os << ", .. ";
    os << "}\tN = " << span.getN();

    return os;
}
